Do not modify this examples.zip file.
This file can be replaced when MultiCommander is updated.
So do not store own or modified version of the script in this file
